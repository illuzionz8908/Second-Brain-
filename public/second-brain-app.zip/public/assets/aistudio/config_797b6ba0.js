
export const JWT_SECRET = "123221";
export const MONGO_URL = "mongodb+srv://warmluke997_db_user:cSqxHqCrJOZcgfz0@cluster0.rrgk38n.mongodb.net/Brainly";